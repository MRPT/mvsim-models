You may use this textures for free in games, even commercial.

See LICENSE.txt for details.

Please also have a look on my other projects:

Gamvas - a HTML5 game engine for the canvas element

http://gamvas.com

Brukkon - a puzzle game using the skybox textures

http://93i.de/cms/products/games/brukkon

Kind Regards,
Heiko Irrgang <hi@93-interactive.com>
