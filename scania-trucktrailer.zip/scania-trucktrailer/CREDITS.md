"Scania Truck+Trailer" (https://skfb.ly/pzAQI) by jsa201077 is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).


