License: vad3d (TurboSquid)
URL: https://www.turbosquid.com/3d-models/free-projector-mast-3d-model/977274

