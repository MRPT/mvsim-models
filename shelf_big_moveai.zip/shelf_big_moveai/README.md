This model is licensed under Creative Commons Attribution Non Commercial 4.0 International

```
@online{GazeboFuel-ctrazziwp-shelf,
	title={shelf},
	organization={Open Robotics},
	date={2022},
	month={December},
	day={4},
	author={ctrazziwp},
	url={https://fuel.gazebosim.org/1.0/ctrazziwp/models/shelf},
}
```

