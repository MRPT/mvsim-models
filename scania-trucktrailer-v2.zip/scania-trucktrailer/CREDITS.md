"Scania Truck+Trailer" (https://skfb.ly/pzAQI) by jsa201077 is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

Modified for MVSim: the tractor and trailer parts were slightly rotated and moved (node transforms only), so all their tires touch the ground.
